
package Koneksi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Koneksi{
    public Connection getConnection(){
        try{
            return DriverManager.getConnection("jdbc:mysql://localhost/toko_roti", "root", "");
            
        } catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public static void main(String[] args) {
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.getConnection();
        if (connection != null) {
            System.out.println("Koneksi berhasil!");
            // Lakukan operasi lain di sini, seperti menjalankan query
            // atau mengakses data dari database
        } else {
            System.out.println("Koneksi gagal!");
        }
    }
}






















//public class Koneksi {
    //public static void main(String[] args){
        // Informasi koneksi ke database
        //String url = "jdbc:mysql://localhost:3306/toko_roti";
        //String username = "root";
        //String password = "";

        // Membuat objek Connection
        //Connection connection = null;

        //try {
            // Membuat koneksi ke database
            //connection = DriverManager.getConnection(url, username, password);
            //System.out.println("Koneksi berhasil!");

            // Lakukan operasi database di sini

        //} catch (SQLException e) {
            //System.out.println("Koneksi gagal: " + e.getMessage());
        //} 
    //}

    //public Connection getConnection() {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    //}
    //}
    
  



//public class Koneksi {
    //Connection conn;
    //public static Connection bukaKoneksi(){
        //try{
            //Class.forName("com.mysql/jdbc.Driver");
            //Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/toko_roti", "root", "");
            //return conn;
        //}catch (Exception e){
            //JOptionPane.showMessageDialog(null, e);
            //return null;
        //}
    //}
//}


//public class Koneksi {
    //public Connection getConnection(){
        //try{
            //return DriverManager.getConnection(
                    //"jdbc:mysql://localhost:3306/toko_rot","root",""
            //);
        //}catch(SQLException ex){
            //throw new RuntimeException(ex);
        //}
    //}
//}



